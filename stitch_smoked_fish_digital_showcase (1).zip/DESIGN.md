---
name: Buoyant Coastal Market
colors:
  surface: '#fbf9f1'
  surface-dim: '#dcdad2'
  surface-bright: '#fbf9f1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f4ec'
  surface-container: '#f0eee6'
  surface-container-high: '#eae8e0'
  surface-container-highest: '#e4e3db'
  on-surface: '#1b1c17'
  on-surface-variant: '#434652'
  inverse-surface: '#30312c'
  inverse-on-surface: '#f3f1e9'
  outline: '#737784'
  outline-variant: '#c3c6d5'
  surface-tint: '#2759bb'
  primary: '#0043a2'
  on-primary: '#ffffff'
  primary-container: '#2a5cbe'
  on-primary-container: '#d1dcff'
  inverse-primary: '#b1c5ff'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fcd664'
  on-secondary-container: '#745c00'
  tertiary: '#005348'
  on-tertiary: '#ffffff'
  tertiary-container: '#196d5f'
  on-tertiary-container: '#9fecda'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#00419e'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e7c353'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#a4f1df'
  tertiary-fixed-dim: '#89d5c4'
  on-tertiary-fixed: '#00201b'
  on-tertiary-fixed-variant: '#005045'
  background: '#fbf9f1'
  on-background: '#1b1c17'
  surface-variant: '#e4e3db'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
---

## Brand & Style
The design system embodies a "Neighborhood Nautical" aesthetic—moving away from sharp maritime precision toward a warm, friendly, and energetic seaside shop feel. The personality is approachable and optimistic, designed to feel like a sun-drenched morning at a coastal boutique.

The design style is **Modern Playful with Tactile Softness**. It prioritizes high-quality whitespace and organic, bubbly containers that evoke the movement of water without the coldness of traditional tech minimalism. The emotional response should be one of comfort, reliability, and whimsy, anchored by the recurring presence of playful cat and fish characters.

## Colors
The palette shifts the "Nautical Modern" foundation into a warmer, more inviting spectrum. 

- **Primary (Deep Sea Blue):** A softened, approachable blue used for key actions and core brand elements.
- **Secondary (Sunny Yellow):** An energetic accent color for highlights, notifications, and "joy" moments.
- **Tertiary (Seafoam Green):** A calming, fresh tone used for secondary accents and success states.
- **Background (Soft Cream):** Replaces stark white with a warm, paper-like cream to reduce eye strain and increase the "artisanal" feel.
- **Neutrals:** Warm grays and soft charcoals are used for text to maintain a high level of legibility without the harshness of pure black.

## Typography
The typography is centered around roundness and legibility. **Hanken Grotesk** provides a sturdy yet friendly structure for headlines, featuring open apertures and a contemporary feel. **Plus Jakarta Sans** is used for body copy to maintain the "soft" geometry across longer reading experiences.

Large headlines should use a tight letter-spacing to create a "bold" shop-sign effect. Labels and small navigational elements should be set in semi-bold Hanken Grotesk to ensure they stand out against the organic shapes of the UI.

## Layout & Spacing
This design system utilizes a **Fluid Grid** with generous padding to emphasize its breezy, coastal nature. 

- **Desktop:** A 12-column grid with wide margins (64px) and comfortable gutters (24px).
- **Mobile:** A 4-column grid with 20px margins.
- **Rhythm:** Spacing follows an 8px scale. To maintain the "friendly" aesthetic, use larger internal padding (md or lg) within containers to prevent content from feeling cramped. Elements should "float" with ample breathing room.

## Elevation & Depth
Depth is created through **Tonal Layering** and **Soft Ambient Shadows**. Avoid harsh borders or heavy black shadows.

- **Surface Tiers:** Use subtle variations of the Cream background to define different zones (e.g., a slightly darker cream for the side nav).
- **Shadows:** Use "Cloud Shadows"—extremely diffused, low-opacity shadows (Opacity 5-8%) with a slight blue or seafoam tint to match the palette.
- **Depth Cues:** Rather than height, depth is often signaled by "nesting" rounded shapes within each other, creating a layered, paper-cut effect.

## Shapes
The shape language is the cornerstone of this design system’s playfulness. It is characterized by **High Roundedness** and **Organic Symmetry**.

- **Primary Shapes:** Buttons and interactive elements use pill-shaped (full radius) geometry.
- **Containers:** Large cards and sections should use the `rounded-xl` or `rounded-2xl` settings to create a "bubbly" feel.
- **Organic Accents:** Use "blob" or "pebble" shapes for background decorations where cat and fish illustrations sit, breaking the rigid verticality of traditional web layouts.

## Components
- **Buttons:** Large, pill-shaped, and high-contrast. The primary button uses the Deep Sea Blue with white text, featuring a subtle "bounce" animation on hover.
- **Chips:** Small, rounded badges using the Sunny Yellow or Seafoam Green to categorize items or display status.
- **Lists:** Items are separated by soft, rounded background hover states rather than divider lines.
- **Input Fields:** Thick, rounded borders in a soft gray, focusing into the primary blue. Labels sit comfortably above the field in a bold weight.
- **Cards:** Heavy use of `rounded-xl`. Feature illustrations (cats/fish) should often "break the frame," peeking out from the top or sides of the card to enhance the playful, energetic vibe.
- **Progress Indicators:** Use "Bubble" bars—rounded tracks with pill-shaped progress fills.